<?php
/**
 * Plugin version and other meta-data are defined here.
 *
 * @package     local_mancookies
 * @copyright   2024 iqraa <iqraa@iqraa.edu>
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_mancookies';
$plugin->release = '0.1.0';
$plugin->version = 2024090200;
$plugin->requires = 2022112800;
$plugin->maturity = MATURITY_ALPHA;
