<?php
/**
 * @package     local_mancookies
 * @author  validationkey    iqraa
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_mancookies;

use dml_exception;
use stdClass;

class manager {

    /** Insert the data into our database table.
     * @param string $machine_text
     * @param string $machine_type
     * @return bool true if successful
     */
    public function get_all_mancookies(): array {
        global $DB;
        return $DB->get_records('user');
    }

    /** Mark that a machine was read by this user.
     * @param int $machine_id the message to mark as read
     * @param int $userid the user that we are marking message read
     * @return bool true if successful
     */
    /** Get a single machine from its id.
     * @param int $machineid the machine we're trying to get.
     * @return object|false machine data or false if not found.
     */
    public function get_mancookies(int $userid)
    {
        global $DB;
        return $DB->get_record('user', ['id' => $userid]);
    }

    
}    