<?php

/**
 * @package     local_mancookies
 * @author      iqraa
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../config.php');

global $DB;

require_login();
$context = context_system::instance();

require_capability('local/mancookies:managemancookies', $context);

$PAGE->set_url(new moodle_url('/local/mancookies/manage.php'));
$PAGE->set_context(\context_system::instance());
$PAGE->set_title(get_string('manage_mancookies', 'local_mancookies'));
$PAGE->set_heading(get_string('manage_mancookies', 'local_mancookies'));
$PAGE->requires->js_call_amd('local_mancookies/confirm');
$PAGE->requires->css('/local/mancookies/styles.css');

$mancookies = $DB->get_records('user', null, 'id');

echo $OUTPUT->header();
$templatecontext = (object)[
    'mancookies' => array_values($mancookies),
    'editurl' => new moodle_url('/local/mancookies/editcookies.php'),
    
];

echo $OUTPUT->render_from_template('local_mancookies/manage', $templatecontext);

echo $OUTPUT->footer();
