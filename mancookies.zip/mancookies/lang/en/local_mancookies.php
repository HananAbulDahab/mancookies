<?php

/**
 * Plugin strings are defined here.
 *
 * @package     local_mancookies
 * @category    string
 * @copyright   2024 iqraa <iqraa@iqraa.edu>
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Manage Cookies';

//$string['pluginname'] = 'man cookies';
$string['manage'] = 'Manage cookies';
$string['setting_enable'] = 'Enable';
$string['setting_enable_desc'] = 'Disable to stop ';
$string['mancookies:view'] = 'Manage mancookies';
$string['manage_Cookies'] = 'Manage cookies';



$string['mancookies:managemancookies'] = 'Manage cookies';


